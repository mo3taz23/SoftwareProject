<html>

<head>
<meta name="viewport" content="width=device-width, initial-scale=1">
<title>LogIn</title>
<link rel="stylesheet" type="text/css" href="css/login.css">


</head>


<body>

<div class="a">
         <h1>LOGIN</h1>
    <div class="b">
    <form action="#" method="post">
    <input type="text"  id = "username"  name="username" placeHolder="User Name" ><br>

    <input class="p" type="password" id = "password"  placeHolder="password" name="password" maxlength="16"><br>
 

        <input type="checkbox" checked="checked" name="remember"> <font style="color: #fff;">Remember me</font>
      <br>
           <input type="submit" value="login" name="submit" method="post" onclick=" return validateForm()">

        </form>

        </div>
    </div>


    <script>




    </script>

</body>

</html>