<!DOCTYPE html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/3.4.1/js/bootstrap.min.js"></script>
  
  <body>
    <?php include "home.php"
    ?>
    <?php include "database.php";

        function signup($mysqli){
            $fname=$pwd=$lname=$age=$telephone=$email=" ";
            $fname = $_POST["firstname"];
            $lname = $_POST["lastname"];
            $email = $_POST["email"];
            $pwd = $_POST["password"];
            $age = $_POST["age"];
            $telephone = $_POST["telephone"];

            if(strlen($pwd)>=6){
                $query = "Select * From Students where email = '".$email."' ; ";
                $result = mysqli_query($mysqli,$query);	

				if($row=mysqli_fetch_array($result)){
                    echo "this email already exist ";
                    
                }

            
            else{
                $mysqli->query("insert into Students (firstname,lastname,age,email,telephone,password,type) values('$fname','$lname','$age', '$email','$telephone','$pwd','0')");
                if(!$mysqli){
                    echo mysqli_error();
                }
                else{
                    echo "You Have Signed In";
                }
            }
        }
        else{
            echo"Password Must Contain More Than 6 Characters";
        }
    }
    ?>
    <?php
        if(isset($_POST["submit"])){
            signup($mysqli);
        }


    ?>
    <div class="main">

        <section class="signup">
            <!-- <img src="images/signup-bg.jpg" alt=""> -->
            <div class="container">
                <div class="signup-content">
                    <form method="POST" id="signup-form" class="signup-form">
                        <h2 class="form-title">Create account</h2>
                        <div class="form-group">
                            <input type="text" class="form-input" name="name" id="firstname" placeholder="First Name"/>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-input" name="name" id="lastname" placeholder="Last Name"/>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-input" name="age" id="age" placeholder="Your Age"/>
                        </div>
                        <div class="form-group">
                            <input type="email" class="form-input" name="email" id="email" placeholder="Your Email"/>
                        </div>
                        <div class="form-group">
                            <input type="text" class="form-input" name="telephone" id="telephone" placeholder="Telephone"/>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-input" name="password" id="password" placeholder="Password"/>
                            <span toggle="#password" class="zmdi zmdi-eye field-icon toggle-password"></span>
                        </div>
                        <div class="form-group">
                            <input type="password" class="form-input" name="re_password" id="re_password" placeholder="Repeat your password"/>
                        </div>
                        <div class="form-group">
                            <input type="checkbox" name="agree-term" id="agree-term" class="agree-term" />
                            <label for="agree-term" class="label-agree-term"><span><span></span></span>I agree all statements in  <a href="#" class="term-service">Terms of service</a></label>
                        </div>
                        <div class="form-group">
                            <input type="submit" name="submit" id="submit" class="form-submit" value="Sign up"/>
                        </div>
                    </form>
                    <p class="loginhere">
                        Have already an account ? <a href="#" class="loginhere-link">Login here</a>
                    </p>
                </div>
            </div>
        </section>

    </div>
    </body>
</html>
